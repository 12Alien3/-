//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by cw092.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CW092TYPE                   129
#define IDD_DIALOG1                     130
#define ID_gray                         32773
#define ID_LINETRANS                    32789
#define ID_HISTOGRAM                    32791
#define ID_EQUALIZE                     32793
#define ID_FT                           32794
#define ID_IFT                          32795
#define ID_FFT                          32796
#define ID_IFFT                         32797
#define ID_AVG_FLITER                   32799
#define ID_MED_FLITER                   32800
#define ID_GRAD_SHARP                   32801
#define ID_RAPLAS_SHARP                 32803
#define ID_BFL_FILTER                   32804
#define ID_BFH_FILTER                   32805
#define ID_IFL_FILTER                   32806
#define ID_IFH_FILTER                   32808

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32809
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
